MONSTER ENERGY FULL-STACK DEMO
================================
Requirements: Node.js 18+

Run:
  npm install
  npm start

Open:
  http://localhost:3000

Shopping:
- Browse Monster can products and sample INR prices.
- Add cans to cart, change quantities, or remove items.
- Proceed to checkout to prefill the order form.
- Complete customer details; orders are saved to data/orders.json.

API:
  GET  /api/health
  GET  /api/flavours
  POST /api/orders

Prices are illustrative demo prices in Indian rupees and can be edited in backend/server.js.
The checkout is a demo order flow; no payment gateway or real delivery partner is connected.
