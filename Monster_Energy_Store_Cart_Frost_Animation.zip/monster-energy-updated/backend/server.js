const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
app.use(express.json());
app.use(express.static(ROOT));
const flavours = [
 {id:'original',name:'Monster Energy Original',sugar:'Original',tagline:'Original Green',size:'350 ml',accent:'#8cff00',image:'assets/original.png',price:125},
 {id:'sunrise',name:'Monster Ultra Sunrise',sugar:'Zero Sugar',tagline:'Ultra Sunrise',size:'500 ml',accent:'#ffb52e',image:'assets/sunrise.png',price:179},
 {id:'blue',name:'Monster Ultra Blue Hawaiian',sugar:'Zero Sugar',tagline:'Ultra Blue Hawaiian',size:'500 ml',accent:'#13d9ff',image:'assets/blue-hawaiian.png',price:179},
 {id:'lewis',name:'Monster Lewis Hamilton',sugar:'Special Edition',tagline:'Lewis Hamilton',size:'500 ml',accent:'#ff3158',image:'assets/lewis-hamilton.png',price:199},
 {id:'white',name:'Monster Ultra White',sugar:'Zero Sugar',tagline:'Ultra White',size:'500 ml',accent:'#d8f4ff',image:'assets/ultra-white.png',price:179}
];
function readOrders(){ try { return JSON.parse(fs.readFileSync(ORDERS_FILE,'utf8')); } catch { return []; } }
app.get('/api/health', (req,res)=>res.json({status:'ok',service:'Monster Energy API',timestamp:new Date().toISOString()}));
app.get('/api/flavours', (req,res)=>res.json(flavours));
app.post('/api/orders', (req,res)=>{
 const {customerName,email,phone,flavourId,quantity,address} = req.body || {};
 const flavour = flavours.find(f=>f.id===flavourId);
 if(!customerName || !email || !phone || !flavour || !Number.isInteger(Number(quantity)) || Number(quantity)<1 || Number(quantity)>20 || !address)
   return res.status(400).json({error:'Please complete all fields and choose a valid flavour and quantity (1–20).'});
 const order = {id:`ME-${Date.now()}`,customerName:String(customerName).trim(),email:String(email).trim(),phone:String(phone).trim(),flavourId,flavour:flavour.name,quantity:Number(quantity),unitPrice:flavour.price,total:flavour.price*Number(quantity),address:String(address).trim(),createdAt:new Date().toISOString(),status:'received'};
 fs.mkdirSync(DATA_DIR,{recursive:true}); const orders=readOrders(); orders.push(order); fs.writeFileSync(ORDERS_FILE,JSON.stringify(orders,null,2));
 res.status(201).json({message:'Order received! Your order has been saved.',order});
});
app.listen(PORT,()=>console.log(`Monster Energy website running at http://localhost:${PORT}`));
